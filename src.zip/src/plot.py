import tensorflow as tf
from tensorflow.keras import layers, Input, Model, regularizers
from tensorflow.keras.utils import plot_model

# 定义主要输入和辅助输入
main_input = Input(shape=(748, 1), name='main_input')
aux_input = Input(shape=(1,), name='aux_input')

# 卷积模块函数
def conv_block(x, filters, kernel_size=3, pool_size=2):
    x = layers.Conv1D(filters=filters, kernel_size=kernel_size, activation='relu',
                      kernel_regularizer=regularizers.l2(0.001))(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling1D(pool_size=pool_size)(x)
    return x

# 共享卷积层
x = conv_block(main_input, filters=32)
x = conv_block(x, filters=64)
x = layers.Flatten()(x)

# 合并输入
combined = layers.Concatenate(axis=-1)([x, aux_input])

# 全连接层模块
def dense_block(x, units, dropout_rate=0.5):
    x = layers.Dense(units=units, activation='relu')(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(rate=dropout_rate)(x)
    return x

# 全连接层
x = dense_block(combined, units=64)
x = dense_block(x, units=32, dropout_rate=0)  # 最后一层不需要 Dropout

# 输出层
output = layers.Dense(units=1, activation='sigmoid', name="cyber_sickness")(x)

# 构建模型
model = Model(inputs=[main_input, aux_input], outputs=output)

# 编译模型
model.compile(
    loss=tf.keras.losses.Huber(),  # 使用 Huber Loss
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
    metrics=['mean_squared_error']
)

# 可视化模型结构并保存为横向展示的图片
plot_model(model, to_file='model_structure_simplified.png', show_shapes=True, show_layer_names=True, rankdir='LR')

# 打印模型摘要
model.summary()
